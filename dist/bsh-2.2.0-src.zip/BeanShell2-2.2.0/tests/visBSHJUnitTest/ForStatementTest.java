import org.junit.*;
import junit.framework.JUnit4TestAdapter;

public class ForStatementTest{
	private ForStatement statement;

	
}