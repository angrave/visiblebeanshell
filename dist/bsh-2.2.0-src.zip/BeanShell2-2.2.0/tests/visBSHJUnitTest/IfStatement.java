import bsh.Interpreter;

public class IfStatement extends Interpreter{
	public static void main(String[] args){
		Interpreter bsh = new Interpreter();
		try{
			bsh.set("ans", 0)	;
			bsh.eval("if(ans == 0)\nreturn 5;\nelse\nreturn 6;");
		} catch (bsh.EvalError e){	
			System.out.print("Threw " + e);
		}
		
	}
}