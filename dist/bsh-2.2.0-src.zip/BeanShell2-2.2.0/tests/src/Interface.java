
public interface Interface 
{
	public String getString();
	public Integer getInteger();
	public int getPrimitiveInt();
	public boolean getPrimitiveBool();
	public Object getNull();
}

