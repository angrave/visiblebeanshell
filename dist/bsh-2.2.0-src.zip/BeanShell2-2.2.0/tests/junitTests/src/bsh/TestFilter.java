package bsh;

public interface TestFilter {

	boolean skip();

}
