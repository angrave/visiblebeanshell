package classes.doppio;

public class JavaScript {

	public native static String eval(String s);
}
